import { Pressable, View, useWindowDimensions } from "react-native"

import { Text } from "@/components/Text"
import { useAppTheme } from "@/theme/context"
import { algu } from "@/theme/alguPalette"

import { alguLogo } from "./alguLogo"
import { alguMono } from "./alguPrimitives"

export interface alguHeaderProps {
  onMenuPress: () => void
  onNavigate: (route: string) => void
  currentRoute: string
}

const TOP_NAV_LINKS: { label: string; route: string }[] = [
  { label: "Our Work", route: "alguHome" },
  { label: "Services", route: "alguServices" },
  { label: "Hire", route: "alguCareers" },
  { label: "Industries", route: "alguIndustries" },
  { label: "Technologies", route: "alguTechnologies" },
]

export function alguHeader({ onMenuPress, onNavigate, currentRoute }: alguHeaderProps) {
  const { theme } = useAppTheme()
  const { spacing } = theme
  const { width } = useWindowDimensions()
  const isWide = width >= 860

  return (
    <View style={{ backgroundColor: "#f2f2f0" }}>
      <View
        style={{
          backgroundColor: "#615e5d",
          paddingHorizontal: spacing.lg,
          paddingVertical: 8,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "flex-end" }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
            <Text
              text="✉ sales@mtechzilla.com"
              style={{
                color: "#f5f4f2",
                fontSize: 14,
                fontWeight: "500",
              }}
            />
            <Text
              text="☎ +1 302 208 5468"
              style={{
                color: "#f5f4f2",
                fontSize: 14,
                fontWeight: "500",
              }}
            />
          </View>
        </View>
      </View>

      <View
        style={{
          backgroundColor: "#f2f2f0",
          borderBottomWidth: 1,
          borderBottomColor: "#d8d7d4",
          paddingHorizontal: spacing.lg,
          paddingVertical: spacing.md,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            gap: spacing.md,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", flex: 1 }}>
            {!isWide ? (
              <Pressable
                onPress={onMenuPress}
                hitSlop={12}
                style={{ marginRight: spacing.md, padding: 4 }}
                accessibilityLabel="Open menu"
                accessibilityRole="button"
              >
                <View style={{ width: 20, height: 2, backgroundColor: algu.ink, marginBottom: 4, borderRadius: 1 }} />
                <View style={{ width: 20, height: 2, backgroundColor: algu.ink, marginBottom: 4, borderRadius: 1 }} />
                <View style={{ width: 20, height: 2, backgroundColor: algu.ink, borderRadius: 1 }} />
              </Pressable>
            ) : null}

            <Pressable onPress={() => onNavigate("alguHome")} accessibilityRole="button">
              <alguLogo size={22} primaryText="ALGU" secondaryText="EDGEX" />
            </Pressable>
          </View>

          {isWide ? (
            <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm, flex: 1, justifyContent: "center" }}>
              {TOP_NAV_LINKS.map((link) => {
                const selected = currentRoute === link.route
                return (
                  <Pressable
                    key={link.route}
                    onPress={() => onNavigate(link.route)}
                    style={{
                      minWidth: 170,
                      minHeight: 50,
                      paddingHorizontal: 18,
                      paddingVertical: 12,
                      borderRadius: 12,
                      borderWidth: 1,
                      borderColor: selected ? "#b7c4d9" : "#d0d1d2",
                      backgroundColor: selected ? "#f7f7f6" : "#f3f2f1",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "center" }}>
                      <Text
                        text={link.label}
                        style={[
                          alguMono,
                          {
                            fontSize: 15,
                            letterSpacing: 0.2,
                            color: selected ? algu.ink : "#2f3746",
                            fontWeight: "500",
                          },
                        ]}
                      />
                      <Text text=" +" style={{ color: "#2f3746", fontSize: 18, marginLeft: 8 }} />
                    </View>
                  </Pressable>
                )
              })}
            </View>
          ) : null}

          <Pressable
            onPress={() => onNavigate("alguContact")}
            style={{
              backgroundColor: "#2f6fe8",
              borderRadius: 12,
              paddingVertical: 12,
              paddingHorizontal: 18,
              alignItems: "center",
              justifyContent: "center",
              minWidth: 150,
            }}
          >
            <Text
              text="Contact Us"
              style={[
                alguMono,
                {
                  color: "#ffffff",
                  fontSize: 15,
                  letterSpacing: 0.2,
                  fontWeight: "700",
                },
              ]}
            />
          </Pressable>
        </View>
      </View>
    </View>
  )
}
