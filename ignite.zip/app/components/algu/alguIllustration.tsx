import { useEffect, useRef } from "react"
import { Animated, Easing, View, ViewStyle } from "react-native"
import { LinearGradient } from "expo-linear-gradient"

import { algu } from "@/theme/alguPalette"

export type alguIllustrationVariant =
  | "home"
  | "products"
  | "services"
  | "technologies"
  | "industries"
  | "departments"
  | "about"
  | "careers"
  | "contact"
  | "leadership"
  | "legal"
  | "governance"
  | "documentation"
  | "api"
  | "whitepapers"
  | "caseStudies"
  | "newsroom"
  | "scientist"

const GLYPHS: Record<alguIllustrationVariant, { shape: Shape; color: string }> = {
  home: { shape: "diamond", color: algu.signal },
  products: { shape: "square", color: algu.silverBright },
  services: { shape: "circles", color: algu.signal },
  technologies: { shape: "ring", color: algu.signal },
  industries: { shape: "ring", color: algu.teal },
  departments: { shape: "bars", color: algu.silverBright },
  about: { shape: "diamond", color: algu.silverBright },
  careers: { shape: "triangle", color: algu.signal },
  contact: { shape: "dot", color: algu.signal },
  leadership: { shape: "bust", color: algu.silverBright },
  legal: { shape: "square", color: algu.steel },
  governance: { shape: "ring", color: algu.signal },
  documentation: { shape: "bars", color: algu.signal },
  api: { shape: "cross", color: algu.teal },
  whitepapers: { shape: "square", color: algu.signal },
  caseStudies: { shape: "circles", color: algu.teal },
  newsroom: { shape: "dot", color: algu.teal },
  scientist: { shape: "bust", color: algu.signal },
}

type Shape = "diamond" | "square" | "circles" | "ring" | "bars" | "triangle" | "cross" | "dot" | "bust"

export interface alguIllustrationProps {
  variant: alguIllustrationVariant
  height?: number
  style?: ViewStyle
}

export function alguIllustration({ variant, height = 180, style }: alguIllustrationProps) {
  const pulse = useRef(new Animated.Value(0)).current
  const { shape, color } = GLYPHS[variant]

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 3200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 3200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    )
    loop.start()
    return () => loop.stop()
  }, [pulse])

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.08] })
  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.7] })

  return (
    <View style={[{ height, borderRadius: 14, overflow: "hidden" }, style]}>
      <LinearGradient
        colors={[algu.ink, algu.surfaceRaised, algu.steel, algu.surfaceRaised, algu.ink]}
        locations={[0, 0.3, 0.5, 0.7, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
      >
        {/* brushed-metal sheen streaks */}
        {[0.12, 0.42, 0.7, 0.88].map((pos) => (
          <View
            key={pos}
            style={{
              position: "absolute",
              top: -20,
              bottom: -20,
              left: `${pos * 100}%`,
              width: 1,
              backgroundColor: "rgba(255,255,255,0.06)",
              transform: [{ skewX: "-18deg" }],
            }}
          />
        ))}

        {/* reactor glow */}
        <Animated.View
          style={{
            position: "absolute",
            width: height * 0.85,
            height: height * 0.85,
            borderRadius: 999,
            backgroundColor: color,
            opacity: glowOpacity,
            transform: [{ scale: glowScale }],
          }}
        />
        <View
          style={{
            width: height * 0.52,
            height: height * 0.52,
            borderRadius: 999,
            borderWidth: 2,
            borderColor: "rgba(228,231,236,0.3)",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(10,12,16,0.35)",
          }}
        >
          <Glyph shape={shape} color={color} size={height * 0.26} />
        </View>
      </LinearGradient>
    </View>
  )
}

function Glyph({ shape, color, size }: { shape: Shape; color: string; size: number }) {
  switch (shape) {
    case "diamond":
      return <View style={{ width: size, height: size, backgroundColor: color, borderRadius: 4, transform: [{ rotate: "45deg" }] }} />
    case "square":
      return <View style={{ width: size, height: size, backgroundColor: color, borderRadius: 6 }} />
    case "circles":
      return (
        <View style={{ flexDirection: "row" }}>
          <View style={{ width: size * 0.65, height: size * 0.65, borderRadius: size * 0.33, backgroundColor: color, marginRight: -size * 0.22 }} />
          <View style={{ width: size * 0.65, height: size * 0.65, borderRadius: size * 0.33, backgroundColor: algu.silverBright, opacity: 0.75 }} />
        </View>
      )
    case "ring":
      return <View style={{ width: size, height: size, borderRadius: size / 2, borderWidth: 3, borderColor: color }} />
    case "bars":
      return (
        <View style={{ flexDirection: "row", alignItems: "flex-end", gap: size * 0.12 }}>
          {[0.5, 0.85, 0.65].map((h, i) => (
            <View key={i} style={{ width: size * 0.18, height: size * h, backgroundColor: color, borderRadius: 2 }} />
          ))}
        </View>
      )
    case "triangle":
      return (
        <View
          style={{
            width: 0,
            height: 0,
            borderLeftWidth: size / 2,
            borderRightWidth: size / 2,
            borderBottomWidth: size,
            borderLeftColor: "transparent",
            borderRightColor: "transparent",
            borderBottomColor: color,
          }}
        />
      )
    case "cross":
      return (
        <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
          <View style={{ position: "absolute", width: size, height: size * 0.22, backgroundColor: color, borderRadius: 2 }} />
          <View style={{ position: "absolute", width: size * 0.22, height: size, backgroundColor: color, borderRadius: 2 }} />
        </View>
      )
    case "dot":
      return <View style={{ width: size * 0.5, height: size * 0.5, borderRadius: size * 0.25, backgroundColor: color }} />
    case "bust":
      return (
        <View style={{ alignItems: "center" }}>
          <View
            style={{
              width: size * 0.44,
              height: size * 0.44,
              borderRadius: size * 0.22,
              backgroundColor: color,
              marginBottom: size * 0.06,
            }}
          />
          <View
            style={{
              width: size * 0.8,
              height: size * 0.42,
              borderTopLeftRadius: size * 0.4,
              borderTopRightRadius: size * 0.4,
              backgroundColor: color,
            }}
          />
        </View>
      )
  }
}
