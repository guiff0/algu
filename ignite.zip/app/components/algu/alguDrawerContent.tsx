import { Pressable, ScrollView, View } from "react-native"

import { Text } from "@/components/Text"
import { LEFT_MENU, PAGES, TOP_NAV } from "@/content/alguContent"
import { useAppTheme } from "@/theme/context"
import { algu } from "@/theme/alguPalette"

import { alguFoldableMenu } from "./alguFoldableMenu"
import { alguLogo } from "./alguLogo"

export interface alguDrawerContentProps {
  onNavigate: (route: string) => void
  onClose: () => void
}

export function alguDrawerContent({ onNavigate, onClose }: alguDrawerContentProps) {
  const { theme } = useAppTheme()
  const { spacing, typography } = theme

  const go = (route: string) => {
    onNavigate(route)
    onClose()
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: algu.surface }}
      contentContainerStyle={{ paddingVertical: spacing.xl, paddingHorizontal: spacing.lg }}
    >
      <alguLogo size={24} style={{ marginBottom: spacing.lg }} />

      <Text
        text="MENU"
        style={{
          fontFamily: typography.primary.medium,
          color: algu.steel,
          fontSize: 11,
          letterSpacing: 2,
          marginBottom: spacing.sm,
        }}
      />
      {TOP_NAV.map((item) =>
        item.route === "alguLearn" ? (
          <alguFoldableMenu
            key={item.route}
            label={item.label}
            sections={PAGES.learn.sections}
            onSelect={() => go(item.route)}
          />
        ) : (
          <Pressable key={item.route} onPress={() => go(item.route)} style={{ paddingVertical: 10 }}>
            <Text text={item.label} style={{ color: algu.text, fontSize: 15 }} />
          </Pressable>
        ),
      )}

      <View style={{ height: 1, backgroundColor: algu.hairline, marginVertical: spacing.lg }} />

      <Text
        text="TECHNICAL SECTIONS"
        style={{
          fontFamily: typography.primary.medium,
          color: algu.steel,
          fontSize: 11,
          letterSpacing: 2,
          marginBottom: spacing.sm,
        }}
      />
      {LEFT_MENU.map((item) => (
        <Pressable
          key={item.label}
          onPress={() =>
            go(
              item.pageKey === "products"
                ? "alguProducts"
                : item.pageKey === "departments"
                  ? "alguDepartments"
                  : "alguServices",
            )
          }
          style={{ paddingVertical: 9 }}
        >
          <Text text={item.label} style={{ color: algu.textDim, fontSize: 13.5 }} />
        </Pressable>
      ))}
    </ScrollView>
  )
}
