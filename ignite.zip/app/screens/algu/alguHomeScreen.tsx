import { FC, useMemo, useState } from "react"
import { Linking, Pressable, View, useWindowDimensions } from "react-native"

import { Text } from "@/components/Text"
import { alguScreenShell } from "@/components/algu/alguScreenShell"
import { HOME_CONTENT } from "@/content/alguContent"
import type { alguStackScreenProps } from "@/navigators/alguNavigationTypes"
import { useAppTheme } from "@/theme/context"

interface alguHomeScreenProps extends alguStackScreenProps<"alguHome"> {}

const primaryNav = [
  { label: "Our Work", route: "alguHome" },
  { label: "Services", route: "alguServices" },
  { label: "Hire", route: "alguCareers" },
  { label: "Industries", route: "alguIndustries" },
  { label: "Technologies", route: "alguTechnologies" },
]

const subMenuItems = [
  "Travel & Hospitality",
  "Renewable Energy",
  "Electric Vehicle",
  "Education",
  "Insurance",
  "Government",
]

const bottomContent = {
  "Travel & Hospitality": {
    icon: "✈",
    title: "Travel & Hospitality",
    body:
      "Want to offer a smoother guest experience? We build custom booking systems, travel apps, and automation tools that make your hospitality services faster, more efficient, and easier to manage.",
  },
  "Renewable Energy": {
    icon: "⚡",
    title: "Renewable Energy",
    body:
      "We design digital systems for energy monitoring, grid intelligence, and portfolio optimization so renewable operations run smarter and scale with certainty.",
  },
  "Electric Vehicle": {
    icon: "⚡",
    title: "Electric Vehicle",
    body:
      "Building EV software? We help you develop powerful apps for fleet tracking, charging stations, and battery monitoring—everything you need to deliver a smart, scalable mobility platform.",
  },
  Education: {
    icon: "▣",
    title: "Education",
    body:
      "We build learning platforms, secure student experiences, and modern digital systems that make education easier to deliver and easier to access.",
  },
  Insurance: {
    icon: "◫",
    title: "Insurance",
    body:
      "From claims systems to risk dashboards and customer portals, we deliver secure digital experiences that streamline policy operations and service quality.",
  },
  Government: {
    icon: "◌",
    title: "Government",
    body:
      "We help agencies modernize workflows, secure digital services, and build resilient platforms that support citizens, operations, and public trust.",
  },
} as const

const defaultSelection = "Travel & Hospitality"

export const alguHomeScreen: FC<alguHomeScreenProps> = function alguHomeScreen({ route, navigation }) {
  const { theme } = useAppTheme()
  const { spacing } = theme
  const { width } = useWindowDimensions()
  const isWide = width >= 920

  const [selectedItem, setSelectedItem] = useState(defaultSelection)

  const activeCards = useMemo(() => {
    const cards = [
      "Travel & Hospitality",
      "Electric Vehicle",
      "Real Estate",
    ].map((label) => ({
      ...bottomContent[label as keyof typeof bottomContent],
      label,
      route: label === "Travel & Hospitality" ? "alguIndustries" : label === "Electric Vehicle" ? "alguServices" : "alguIndustries",
    }))

    return cards
  }, [])

  const openMail = () => Linking.openURL(`mailto:${HOME_CONTENT.contactEmail}`)
  const goTo = (r: string) => navigation.navigate(r as never)

  return (
    <alguScreenShell currentRoute={route.name} onNavigate={(r) => navigation.navigate(r as never)}>
      <View style={{ backgroundColor: "#d9d6d3", paddingBottom: spacing.xxl }}>
        <View style={{ maxWidth: 1760, width: "100%", alignSelf: "center" }}>
          <View style={{ backgroundColor: "#5d5a58", paddingHorizontal: spacing.lg, paddingVertical: 10 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "flex-end" }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 18 }}>
                <Text text="✉ sales@mtechzilla.com" style={{ color: "#f3f2f0", fontSize: 14, fontWeight: "500" }} />
                <Text text="☎ +1 302 208 5468" style={{ color: "#f3f2f0", fontSize: 14, fontWeight: "500" }} />
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: "#f2f1ef", paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: "#d3d0ce" }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.md }}>
              <Pressable onPress={() => goTo("alguHome")} style={{ flexDirection: "row", alignItems: "center" }}>
                <View
                  style={{
                    width: 26,
                    height: 26,
                    borderRadius: 7,
                    backgroundColor: "#2e6fe9",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 8,
                  }}
                >
                  <Text text="X" style={{ color: "#fff", fontSize: 16, fontWeight: "800" }} />
                </View>
                <Text text="MTechZilla" style={{ color: "#0b1725", fontSize: isWide ? 30 : 26, fontWeight: "800" }} />
              </Pressable>

              <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: spacing.sm, flex: 1, paddingHorizontal: 8 }}>
                {primaryNav.map((item) => (
                  <Pressable
                    key={item.label}
                    onPress={() => goTo(item.route)}
                    style={{
                      minWidth: isWide ? 170 : 140,
                      minHeight: 52,
                      paddingHorizontal: 18,
                      paddingVertical: 12,
                      borderRadius: 12,
                      borderWidth: 1,
                      borderColor: "#d0d1d2",
                      backgroundColor: "#f3f2f1",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "center" }}>
                      <Text text={item.label} style={{ color: "#1a2331", fontSize: 18, fontWeight: "500" }} />
                      <Text text=" +" style={{ color: "#1a2331", fontSize: 18, marginLeft: 8 }} />
                    </View>
                  </Pressable>
                ))}
              </View>

              <Pressable
                onPress={() => goTo("alguContact")}
                style={{
                  backgroundColor: "#2f6fe8",
                  borderRadius: 12,
                  paddingVertical: 12,
                  paddingHorizontal: 18,
                  minWidth: 150,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text text="Contact Us" style={{ color: "#fff", fontSize: 18, fontWeight: "700" }} />
              </Pressable>
            </View>
          </View>

          <View style={{ backgroundColor: "#dfe0df", paddingHorizontal: spacing.lg, paddingTop: spacing.lg, paddingBottom: 0 }}>
            <View
              style={{
                backgroundColor: "#efefed",
                borderRadius: 18,
                borderWidth: 1,
                borderColor: "#d7d5d2",
                overflow: "hidden",
              }}
            >
              <View style={{ flexDirection: isWide ? "row" : "column", alignItems: "stretch" }}>
                <View style={{ flex: 1, padding: spacing.lg, paddingRight: isWide ? spacing.xl : spacing.lg, justifyContent: "center" }}>
                  <Text
                    text="Build your next idea with our team of experts!"
                    style={{ color: "#0d1721", fontSize: isWide ? 62 : 42, lineHeight: isWide ? 68 : 52, fontWeight: "700" }}
                  />

                  <Pressable
                    onPress={openMail}
                    style={{
                      marginTop: spacing.lg,
                      alignSelf: "flex-start",
                      backgroundColor: "#efefec",
                      borderRadius: 12,
                      borderWidth: 1,
                      borderColor: "#c9c6c3",
                      paddingVertical: 16,
                      paddingHorizontal: 24,
                    }}
                  >
                    <Text text="Get a Proposal" style={{ color: "#1c2531", fontSize: 18, fontWeight: "600" }} />
                  </Pressable>
                </View>

                <View style={{ flex: 1.15, padding: spacing.md }}>
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 12 }}>
                    {subMenuItems.map((industry) => {
                      const isSelected = industry === selectedItem
                      return (
                        <Pressable
                          key={industry}
                          onPress={() => setSelectedItem(industry)}
                          style={{
                            width: isWide ? "48%" : "100%",
                            minHeight: 82,
                            paddingHorizontal: 20,
                            paddingVertical: 18,
                            borderRadius: 12,
                            borderWidth: 1,
                            borderColor: isSelected ? "#d0cfcf" : "#d9d7d4",
                            backgroundColor: isSelected ? "#f8f8f7" : "#f4f3f2",
                            flexDirection: "row",
                            justifyContent: "space-between",
                            alignItems: "center",
                          }}
                        >
                          <Text text={industry} style={{ color: "#1a2330", fontSize: 26, fontWeight: "500" }} />
                          <Text text="↗" style={{ color: "#1a2330", fontSize: 30, fontWeight: "700" }} />
                        </Pressable>
                      )
                    })}
                  </View>
                </View>
              </View>
            </View>
          </View>

          <View style={{ paddingHorizontal: spacing.lg, marginTop: spacing.xl }}>
            <View style={{ flexDirection: isWide ? "row" : "column", gap: spacing.md }}>
              {activeCards.map((card) => (
                <Pressable key={card.title} onPress={() => goTo(card.route)} style={{ flex: 1 }}>
                  <View
                    style={{
                      backgroundColor: "#111720",
                      borderRadius: 18,
                      minHeight: 310,
                      padding: spacing.lg,
                      justifyContent: "space-between",
                      borderWidth: 1,
                      borderColor: "#2f3845",
                    }}
                  >
                    <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "#2d6fe8", alignItems: "center", justifyContent: "center" }}>
                      <Text text={card.icon} style={{ color: "#fff", fontSize: 18 }} />
                    </View>

                    <View style={{ marginTop: spacing.md }}>
                      <Text text={card.title} style={{ color: "#f3f7fb", fontSize: 34, lineHeight: 40, fontWeight: "700" }} />
                      <Text text={card.body} style={{ color: "#d1d8e2", fontSize: 17, lineHeight: 30, marginTop: spacing.sm }} />
                    </View>

                    <Text text="Know More →" style={{ color: "#ffffff", fontSize: 18, marginTop: spacing.md, fontWeight: "600" }} />
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      </View>
    </alguScreenShell>
  )
}

