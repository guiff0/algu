import { HOME_CONTENT, PAGES } from "../app/content/alguContent"

describe("contractor-facing readiness content", () => {
  it("includes a public website and government contracting message", () => {
    const text = `${HOME_CONTENT.body} ${HOME_CONTENT.subBody}`.toLowerCase()
    expect(text).toContain("website")
    expect(text).toContain("capabilities statement")
    expect(text).toContain("government")
    expect(text).toContain("quantum")
    expect(text).toContain("ai")
  })

  it("makes the capabilities statement and company profile easy to find", () => {
    const intro = PAGES.about.intro.toLowerCase()
    expect(intro).toContain("capabilities statement")
    expect(intro).toContain("government")
    expect(PAGES.about.sections[0].items.some((item) => item.title.toLowerCase().includes("website"))).toBe(true)
  })
})
